# FOMO Discord Bot

Fresh Discord bot starter with:
- `!ping`
- `!hello`
- `!helpme`
- Secure `DISCORD_TOKEN` environment variable
- Discord Message Content Intent support

## Environment variable

Set:

`DISCORD_TOKEN=your_private_bot_token`

Never commit or share your token.
